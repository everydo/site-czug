This is a simple Skins installer for CMF/Plone.


INSTALLATION

  * Zope   - http://www.zope.org

  * Plone  - http://www.plone.org

Quickstart:

1) copy hhdsskins to Products

2)  Use the QuickInstaller tool to register hhdsskins in your plone instance or 
  add and run Extensions/Install/install as an external method after plone 
  is installed.

Enjoy!
