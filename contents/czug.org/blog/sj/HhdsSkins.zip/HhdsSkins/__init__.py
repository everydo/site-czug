##############################################################
# register the policy
from Products.HhdsSkins import CustomizationPolicy
from config import *

Hhdsskins_globals = globals()

def initialize(context):
    CustomizationPolicy.register(context, globals())

##############################################################
# register the directories
from Products.CMFCore.DirectoryView import registerDirectory
for i in range(len(skins)):
    registerDirectory(skins[i]['name'], globals())