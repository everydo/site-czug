from Products.CMFCore.utils import getToolByName
from Products.CMFCore.Expression import Expression
from Products.CMFCore import CMFCorePermissions
from Products.CMFCore.DirectoryView import addDirectoryViews, registerDirectory
from Products.CMFPlone.Portal import addPolicy
from Products.CMFPlone.migrations.migration_util import safeEditProperty
from Products.ZopeChinaPak.PlonePak import ZopeChinaDefaultCustomizationPolicy
import Globals
from config import *

hhdsskins_globals = globals()

class zh_cnCustomizationPolicy(ZopeChinaDefaultCustomizationPolicy):
	""" Customises plone for HhdsSkins """

	def customize(self, portal):
		# do the base Default install, that gets
		# most of it right
		ZopeChinaDefaultCustomizationPolicy.customize(self, portal)
		p=portal.portal_properties.site_properties
		safeEditProperty(p, 'default_language', 'zh-cn', 'string')

class CustomizationPolicy(ZopeChinaDefaultCustomizationPolicy):
	""" Customises plone for HhdsSkins """

	try:
		screenshot_jpg = Globals.ImageFile('skin01/os01/screenshot.jpg',hhdsskins_globals)
		screenshot = {'image': screenshot_jpg}
	except:
		screenshot = None
		
	_dirs = ('')
	skinsname = ''
		
	def customize(self, portal):
		# do the base Default install, that gets
		# most of it right
		ZopeChinaDefaultCustomizationPolicy.customize(self, portal)
		p=portal.portal_properties.site_properties
		safeEditProperty(p, 'default_language', 'zh-cn', 'string')

		# set up the skins


		sk_tool = getToolByName(portal, 'portal_skins')
		defpath=[elem.strip() for elem in sk_tool.getSkinPath('Plone Default').split(',')]
		paths = defpath[:]
		for d in _dirs[i]:
			try: paths.insert(paths.index('custom')+1, d)
			except ValueError: paths.append(d)
			path=','.join(paths)
			sk_tool.addSkinSelection(skinsname[i], path)

		addDirectoryViews(sk_tool, skinsname, globals())

		# set default
		sk_tool.default_skin = skinsname


def register(context, app_state):
	for i in range(len(skins)):
		CustomizationPolicy._dirs=skins[i]['dirs']
		CustomizationPolicy.skinsname=skins[i]['name']
		addPolicy(skins[i]['name'], CustomizationPolicy())
	
	
	addPolicy('Default Plone(zh_cn)', zh_cnCustomizationPolicy())
