#-----------------------------------------------------------------------------
# Author:      Liu Bin
# Reference:   OssaccSkins
# Created:     2004/11/15
# Copyright:   (c) 2004 hhds.gov.cn
# License:     GPL
#-----------------------------------------------------------------------------

"""
CMF hhdsSkins Installation script

 id:            cmf_install_hhdsskins
 title:         
 module name:   HhdsSkins.Install
 function name: install
"""

from cStringIO import StringIO
from Products.CMFCore.DirectoryView import addDirectoryViews
from Products.CMFCore.utils import getToolByName
from Products.HhdsSkins import Hhdsskins_globals
from Products.HhdsSkins.config import *

def install(self):
    """
    Register "HhdsSkins" with skins.
    """
    out = StringIO()
    skinstool = getToolByName(self, 'portal_skins')
    
    # Setup the skins
    for i in range(len(skins)):
        _name=skins[i]['name']
        _dirs=skins[i]['dirs']
        if _name not in skinstool.objectIds():           
            defpath=[elem.strip() for elem in skinstool.getSkinPath('Plone Default').split(',')]
            paths = defpath[:]
            for d in _dirs:
                try: paths.insert(paths.index('custom')+1, d)
                except ValueError: paths.append(d)
                path=','.join(paths)
                skinstool.addSkinSelection(_name, path)
            addDirectoryViews(skinstool, _name, Hhdsskins_globals)
            out.write("Added "+_name+" skin directories to portal_skins\n")
        
    # set default
    skinstool.default_skin = _name

    return out.getvalue()
