# -*- coding: utf-8 -*-
""" Example.py 文件
定义并注册文档类型 "Example"

	沈崴 <eishn@163.com>
"""

# [导入依赖模块及组件]
#

# 主要是从 Archetypes 中导入需要的 Fields 和 Widgets,
# 以及文档类型的基类。
# 最后是类型注册工具 registerType。

# 导入 Field
#

# [!] 知识条目: Field

# 所谓 Field, 是指类似于表单字段那样的东西。
# Field 用于描述文档类型其对象中的一个属性。
# Field 指定了该字段属性的类型,
# 是字符串(StringField)还是整形(IntegetField), 亦或其他类型。

# Plone 的官方站点中有所有可用的 Field 的列表
# 这里给出 Archetypes 1.3.1 版本的 Field Quick Reference 的地址:
# http://plone.org/documentation/archetypes/arch_field_quickref_1_3_1

from Products.Archetypes.public import StringField

# 导入 Widget:
#

# [!] 知识条目: Widget

# 所谓 Widget, 是 Field 所用到的表现组件,
# 同样是 StringField, 我们可以用行编辑器(StringWidget)给它赋值,
# 也可以用多行编辑器(TextAreaWidget), 或者通过文件上传该 Field 的值。

# Plone 的官方站点中有所有可用的 Widget 的列表
# 这里给出 Archetypes 1.3.1 版本的 Widget Quick Reference 的地址:
# http://plone.org/documentation/archetypes/arch_widget_quickref_1_3_1

from Products.Archetypes.public import TextAreaWidget

# 导入 Schema
#

# [!] 知识条目: Schema
# 所谓 Schema 描述了整个文档对象, 包括
# 文档对象有多少 Field 分别是何类型的 Field, 以及
# 使用何种 Widget 来录入 Field

# 这里, 我们将直接使用已经定义好的普通文档对象的 Schema: BaseContentSchema
# 并在该 BaseContentSchema 的基础上建立起我们自己的文档对象的 Schema
# 附加的 Schema 通过 Products.Archetypes.public.Schema 来编写

from Products.Archetypes.public import BaseSchema, Schema

# 导入文档类型的基类
#

# 普通的文档类型, 如果不带有文件夹的特性可以使用 BaseContent 作为基类
# 如果是一个文件夹则使用 BaseFolder, BaseBTreeFolder 等基类, 这将在下面几课中讲到。

from Products.Archetypes.public import BaseContent

# registerType 工具
#

from Products.Archetypes.public import registerType

# [表单样式 (Schema) 定义]
#

# BaseSchema 中已经定义了 Id 和 Title 两个 Field
# 这里我手工添加了一个叫做 content 的新 StringField

# StringField 中用到了参数 required, default 和 widget
# - required 指定了这个字段是否是必须的。
# - default 指定了默认值。
# - widget 指定了该字段使用的输入组件

schema = BaseSchema + Schema( (
	StringField("content",
		required   = False,
		default    = "",
		widget     = TextAreaWidget(
			label = "内容"
		)
	),
), )

# [文档类型定义]
#

# [!] 注意: 这里定义的类名称将会被 Plone 获得
#           并作为文档类型的名称

# 该文档类型可以在 Plone 的添加菜单中找到,
# 不过它是以英文名称出现的 "Example"。

# [!] 小技巧:
# 将其改变为中文名称的最简单的方法是:
# 在 ZMI 中 "/portal_types" 里修改 "Example" 的
# Title 字段为中文名称, 例如 "范例1"

class Example(BaseContent):
	"""一个简单的文档类型的范例
(你会惊奇地发现这行注释将出现在 Plone 客户端, 作为 Example 的描述)"""

	# 元类型
	meta_type = "Example" # 还记得 "__init__.py" 里面的
	#                      # "get_type_index(...)" 函数吗?

	# 图标
	content_icon = "document_icon.gif"

	# 应用样式
	schema = schema

# 注册资料类型
registerType(Example)
