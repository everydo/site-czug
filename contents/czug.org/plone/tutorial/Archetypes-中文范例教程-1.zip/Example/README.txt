﻿这是关于 Archetypes 编程的第一课。整个 Product 的结构我参考了 ArchExample 产品, 去掉了 Skin 部分, 显得更简单, 更容易入门。

这个 Product 从某种程度上讲已经是最简单的了, 尽管如此, 还是颇为典型。我们可以在她的基础上发展出我们自己的应用, 因为我们通常并不会用到 Archtypes 的所有特性。通过最简单的方法透过少量的特性我们就能做出庞大的应用, 因为这是 Archetypes '这就是 Plone'!

建议阅读顺序: 1)'Example.py'、2)'__init__.py'、3)'Extensions/Install.py'。建议源码浏览器: Python Idle 或其他支持 UTF-8 编码的编辑器。

最后请各位尽情地享受中文的 Archetypes 课程, 以及中文的注释吧 :)

REQUIREMENTS

  * Plone 2.0 RC6+

INSTALLATION

  将本文件夹 "Example" 拷贝到你的 Products 目录下。重启 Plone。登录为管理员使用 QuickInstaller 安装本产品到 Plone 上。

CONTACT

  沈崴 eishn@163.com