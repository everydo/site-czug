# -*- coding: utf-8 -*-
""" __init__.py 文件
初始化 Product, 并注册文档类型。

	沈崴 <eishn@163.com>
"""

# [!] 警告: 关于文件编码
#

# 事实上第一行 "-*- coding: utf-8 -*-"
# 并不是如我们想象中那样可有可无。
# Archetypes 会读取 """ ... xxx ... """
# 这种类型的注释, 通常作为描述而显示到用户界面中去。
# 这就是说我们不能像编写普通的 Python 程序
# 那样随意地使用 __doc__ 类型的注释,
# 另外因为 __doc__ 会被显示到客户端,
# 所以使用 UTF-8 这种更为通用的编码似乎更为合理。


# [GLOBALS AND PROJECTNAME]
#

# 其实这两个变量并不是一定要放在 config 里面
# 然后在这里倒入, 请注意, 这仅仅是惯例而已(官方推荐)。
# 在熟悉使用 Archetypes 的过程中, 我们最好是尝试
# 使用惯例来编程。

# 同样往 config.py 文件看去, 其结构也是一个惯例
# 大家以后做开发的时候只要照做就可以了 :)

from config import GLOBALS, PROJECTNAME


# [例行公事]
#

# 下面的这些工具通常都会用到, 可以看作是 "例行公事"。

from Products.Archetypes.public import process_types, listTypes
from Products.CMFCore import utils


# [导入标准的 CMF 权限]
#

# 没错, 这个就是我们在 Plone 权限管理中经常会遇到的
# "Add Portal Content" 授权。

from Products.CMFCore.permissions import AddPortalContent

# 事实上, 权限不过是一个类似于 "Add Portal Content"
# 这样的字符串。
#

# 换言之, 我们可以如此简单地加入我们自己的权限配置:
# 	MY_PERMISSION = "My Permission"


# [得到文档类型的 index]
#

# 得到文档类型 index (这里的文档类型将在 Example.py 中定义) 的函数。
# 这个工具函数是进行下面 Product 初始化所需要的。
# 事实上, 这个函数是从一个名为
# SimpleBlog 的 Plone 产品中照搬出来的。
# 笔者中意于这个实现, 并且推荐大家使用。

def get_type_index(content_types, meta_type):
	# [!] 注意: 这里通过 meta_type 来取得文档类型
	#           meta_type 设定于文档类型的定义文件中
	#           请参见 Example.py

	for i in range(len(content_types)):
		if content_types[i].meta_type == meta_type:
			return i


# [初始化函数]
#

# 初始化函数 "initialize" 是 __init__.py 文件的核心。
# Zope 启动时, 会自动读取 Products 文件夹,
# 导入本 __init__.py 文件夹,
# 并自动执行这个 initialize 函数。

# 这里给出一个简单的范例, 随着 Product 的丰富
# initialize 会逐渐变得复杂。
# 我会在下面几节课里给出演示。

def initialize(context):
	""" 产品 Example 初始化函数 """

	# [导入文档类型]
	#

	# 这是首先要做的事情, 我们要导入我们编写的文档类型。
	# 在此导入(并注册)所有文档对象:
	import Example # 演示范例 Example


	# [例行公事]
	#

	# 得到 content_types, constructors, ftis
	# 只是又一次例行公事而已。
	content_types, constructors, ftis = process_types(
		listTypes(PROJECTNAME),
		PROJECTNAME
	)


	# [得到文档对象的 index]
	# (使用 meta_dat 来得到索引)
	#

	exam1_index = get_type_index(content_types, 'Example')


	# [生成 Constructors, Content Types]
	#

	# 每一种权限对应了一组 Constructors 和一组 Content Types
	# 必要时可以为几组不同的 Permission 设计几组 Constructors
	# 和 Content Types。
	#

	# 1. Constructors
	exam1_constructors = []
	exam1_constructors.append(constructors[exam1_index])

	# 2. Content Types
	exam1_types = []
	exam1_types.append(content_types[exam1_index])


	# [执行初始化]
	#

	# 对应每一种 Permission 需要相应执行一次初始化
	# 这里仅有一种 Permission 和 Content Type,
	# 更为复杂的情况我将在下面几节课里面展示给你。

	# 第一个参数: PROJECTNAME + " Content"
	# 是文档类型在 ZMI 中的现示名称, 可以在 ZMI 添加菜单中看到

	# 后面分别设定 Content Types, Permission, Constructors

	utils.ContentInit(
		PROJECTNAME + " Content",
		content_types      = tuple(exam1_types),
		permission         = AddPortalContent,
		extra_constructors = tuple(exam1_constructors),
		fti                = ftis
	).initialize(context)
