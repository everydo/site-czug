# -*- coding: utf-8 -*-
""" config.py 文件
配置文件

	沈崴 <eishn@163.com>
"""

# [常见的配置]
#

# 也许下面的课程中会增加其它配置,
# 但是注意下面两个配置是比较基本的。
# 它非常通用, 并且很少改变(当然项目名称可不要照抄哦)。

PROJECTNAME = "Example"
GLOBALS = globals()
