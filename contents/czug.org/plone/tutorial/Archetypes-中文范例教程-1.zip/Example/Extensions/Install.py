# -*- coding: utf-8 -*-
""" Install.py 文件
安装 Product

	沈崴 <eishn@163.com>
"""

# 事实上这个 "Install.py" 的写法也是比较固定的
# 在你的项目中通常只要照搬就可以了 :)

# 当然这个程序也可以变得很丰富, 不过在此之前我们
# 得先熟悉一下 Archetypes 的其他特性。

# [导入工具]
#

from Products.Archetypes.public import listTypes
from Products.Archetypes.Extensions.utils import installTypes

# [导入配置]
#

# [!] 注意: 这里请使用全路经。

from Products.Example.config import PROJECTNAME, GLOBALS

# [StringIO]
#

# 作为安装日志信息的容器

from StringIO import StringIO

# 安装函数
def install(self):
	"""安装产品"""

	# 建立安装信息的容器
	out = StringIO()

	installTypes(self, out, listTypes(PROJECTNAME), PROJECTNAME)

	# 人称安装成功
	out.write("Successfully installed %s." % PROJECTNAME)
	return out.getvalue()
